1)parsestring.java is main file
