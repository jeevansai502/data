
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author placements2017
 */
public class lexe {
    
    public static void main(String args[]) throws FileNotFoundException{
    
        Scanner sc = new Scanner(new File("input.txt")).useDelimiter("\\z");
        
        String str = sc.next();
        
        ArrayList<>
        
        
        
        
        
        
        Pattern p = new Pattern();
        
        
        
        
        
        
    }

}
