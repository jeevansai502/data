I = imread('face.jpg');
B = im2bw(I,0.5);
[K,num1] = bwlabel(B,4);
[L,num2] = bwlabel(B,8);
disp(num1);
disp(num2);
imshow(L);