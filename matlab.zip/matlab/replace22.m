I = rgb2gray(imread('image.jpg'));
[m,n] = size(I);

if mod(m,2)==1
    p = fix((m+1)/2);
    r = m;
    I(m)=0;
else 
    p = m/2;
    r = m-1;
end

if mod(n,2)==1
    q = fix((n+1)/2);
    s = n;
    I(n)=0;
else
    q = n/2;
    s = n-1;
end
    
arr1 = zeros(p,q);
a=1;
b=1;
for y = 1:r
    for x = 1:s
        avg = fix(I(y,x)/4+I(y+1,x+1)/4+I(y,x+1)/4+I(y+1,x)/4);
        arr1(a,b) = avg;
        if a<p
             a = a+1;
        else
            b=b+1;
            a=1;
        end
        if x+1<s+1 
             x = x+1;
        else 
            y = y+1;
            x =1;
        end
    end
end

%arr1 = (N1 - min(N1(:)))/(max(N1(:)) - min(N1(:)));

%{
arr2 = zeros(p,q);
a=1;
b=1;

for y = 1:r
    for x = 1:s
        
        c = [I(y,x) I(y+1,x+1) I(y,x+1) I(y+1,x)];
        med = median(c,1);
        arr2(a,b) = med(1,1);
        
        if a<p
             a = a+1;
        else
            b=b+1;
            a=1;
        end
        
    end
end

subplot(2,1,1),imshow(arr1);
subplot(2,1,2),imshow(arr2);
%}

imshow(arr1);
