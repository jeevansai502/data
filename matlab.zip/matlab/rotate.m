I = imread('image.jpg');
R = imrotate(I,45);
imshow(R);