I = imread('face.jpg');
N = imnoise(I,'gaussian');
imshow(N);