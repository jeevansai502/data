rect1 = [0 0 300 280];
%rect2 = [300 0 300 280];
%rect3 = [0 280 300 280];
%rect4 = [300 280 300 280];

I = rgb2gray(imread('car.jpg'))
I1 = imcrop(I,rect1);
%I2 = imcrop(I,rect2);
%I3 = imcrop(I,rect3);
%I4 = imcrop(I,rect4);
imwrite(I1,'valley.jpg');
%imwrite(I2,'face1.jpg');
%imwrite(I3,'car1.jpg');
%imwrite(I4,'fruit1.jpg');




