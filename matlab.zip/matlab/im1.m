I = imread('image.jpg');
i1 = int8(I);
i2 = im2uint16(I);
i3 = im2int16(I);
i4 = im2single(I);
i5 = im2double(I);


subplot(3,2,1),imshow(rgb2gray(i1));
title('int8')
subplot(3,2,2),imshow(rgb2gray(i2));
title('uint16')
subplot(3,2,3),imshow(rgb2gray(i3));
title('int16')
subplot(3,2,4),imshow(rgb2gray(i4));
title('single')

subplot(3,2,5),imshow(rgb2gray(i5));
title('double')