I = imread('face.jpg');

rect1 = [70 ,50 ,50 ,50];
rect2 = [150 ,50 ,50 ,50];
rect3 = [130 ,70 ,30 ,60];
rect4 = [100 ,130 ,100 ,100];

eye1 = imcrop(I,rect1);
eye2 = imcrop(I,rect2);
imwrite(eye1,'eye1.jpg');
imwrite(eye2,'eye2.jpg');
nose = imcrop(I,rect3);
lips = imcrop(I,rect4);

subplot(2,2,1),imshow(eye1);
subplot(2,2,2),imshow(eye2);
subplot(2,2,3),imshow(nose);
subplot(2,2,4),imshow(lips);