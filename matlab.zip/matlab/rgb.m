I = imread('image.jpg');
[m,n] = size(I);
R = zeros(n,m,3);
for i=1:m-1
    for j=1:n-1
            R(i,j,1) = I(i,j,1);
    end
end
        
subplot(3,1,1),imshow(R);
G = zeros(m,n,3);

for i=1:m-1
    for j=1:n-1
            G(i,j,2) = I(i,j,2);
    end
end

subplot(3,1,2),imshow(G);
B = zeros(m,n,3);

for i=1:m-1
    for j=1:n-1
            B(i,j,3) = I(i,j,3);
    end
end
subplot(3,1,3),imshow(B);
