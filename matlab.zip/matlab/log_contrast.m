I = imread('image1.jpg');
I = rgb2gray(I);
I = im2double(I);
[m,n] = size(I);
A = zeros(m,n);

for i = 1:m
    for j = 1:n
        A(i,j) = 1*(log(double(I(i,j)+1)));
    end
end

imshow(A);