I = imread('Image_2.bmp');

B = bwmorph(I,'open');

subplot(2,1,1),imshow(I);
subplot(2,1,2),imshow(B);