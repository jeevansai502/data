I = imread('eye1.jpg'); 
I = rgb2gray(I);
h = imhist(I); 
 
J = imread('eye2.jpg'); 
J = rgb2gray(J);
h1 = imhist(J);  
E_distance = sqrt(sum((h-h1).^2));
disp(E_distance)