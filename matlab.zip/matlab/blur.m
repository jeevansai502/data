I = im2double(rgb2gray(imread('Earth.jpg')));
h = fspecial('average',[3 3]);

B = imfilter(I,h);
M = imsubtract(B,I);
A = imadd(I,M);

subplot(2,2,1),imshow(I),title('original');
subplot(2,2,2),imshow(B),title('blur');
subplot(2,2,3),imshow(M),title('mask');
subplot(2,2,4),imshow(A),title('added');