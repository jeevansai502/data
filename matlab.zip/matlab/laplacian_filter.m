I = im2double(rgb2gray(imread('Earth.jpg')));
h1 = fspecial('laplacian',0.9);
S = imfilter(I,h1);

h2 = fspecial('laplacian',0.2);
A = imfilter(I,h2);

N1 =  imadd(I,S) ;
N1 = (N1 - min(N1(:)))/(max(N1(:)) - min(N1(:)));

N2 =  imadd(I,A) ;
N2 = (N2 - min(N2(:)))/(max(N2(:)) - min(N2(:)));


subplot(2,3,1),imshow(I),title('original');
subplot(2,3,2),imshow(S),title('filtered');
subplot(2,3,3),imshow(A),title('filtered,scaled');
subplot(2,3,4),imshow(N1),title('masked1');
subplot(2,3,5),imshow(N2),title('masked2');
