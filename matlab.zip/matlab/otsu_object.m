I = imread('seg_image.jpg');

[counts,x] = imhist(I,8);

level = otsuthresh(counts);
BW = im2bw(I,level);
imshow(BW);