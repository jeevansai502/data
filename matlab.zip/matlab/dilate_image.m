I = imread('Image_1.bmp');
I1 = imread('Image_1.bmp');
SE = strel('square',3);

for i = 1:1:4
    
    I1 = imdilate(I1,SE);
    
end

subplot(3,1,1),imshow(I);
subplot(3,1,2),imshow(I1);
subplot(3,1,3),imshow(imsubtract(I1,I));
