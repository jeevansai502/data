I1 = imread('face1.jpg');
I2 = imread('car1.jpg');
I3 = imread('valley1.jpg');
I4 = imread('fruit1.jpg');

arr1 = histogram_loop(I1);
arr2 = histogram_loop(I2);
arr3 = histogram_loop(I3);
arr4 = histogram_loop(I4);


subplot(4,1,1),bar(arr1);
subplot(4,1,2),bar(arr2);
subplot(4,1,3),bar(arr3);
subplot(4,1,4),bar(arr4);