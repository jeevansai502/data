I = imread('Image_3.bmp');

B = imfill(I,'holes');

subplot(2,1,1),imshow(I);
subplot(2,1,2),imshow(B);