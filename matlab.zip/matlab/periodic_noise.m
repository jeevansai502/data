I = imread('grid_image.jpg');
I1 = fft2(I);
val1 = fftshift(I1);
%imshow(fftshift(I1));
%disp(abs(I1));
val = log(1+abs(fftshift(I1)));
%imshow(val);
%imshow(log(1+abs(fftshift(I1))),[]);
I2 = log(1+abs(fftshift(I1)));

[m n] = size(I2);
maxValue = max(I2(:));
%disp(maxValue);
M = zeros(m,n);

me = mean(I2(:));

%filter = (val > maxValue) | (val < 0.08*maxValue);

%imshow(filter);

%B = ifft2(val1.*filter);
%imshow(medfilt2(B,[23 23]));

for i = 1:1:m
    for j = 1:1:n
        
        if I2(i,j) == maxValue
            I2(i,j) = me;
            M(i,j) = 1;
        end
    end
end

imshow(ifft2(I2));

%{
subplot(2,2,1),imshow(I);
subplot(2,2,2),imshow(log(1+abs(fftshift(I1))),[]);
subplot(2,2,3),imshow(M);
subplot(2,2,4),imshow(ifft(I2));
%}
%imshow(ifft2(M));

%{
h = fspecial( 'gaussian', sz, 0.5 );
H = fft2(h);
F = I1.*H;
f = ifft2(F);
imshow(f);
%}