I = rgb2gray(imread('face.jpg'));

[m,n] = size(I);

I1 = zeros(m,n,8);

for i=1:1:m
    for j=1:1:n
        str = dec2bin( I(i,j) , 8 );
        for k=1:1:8

            if( str(k) == '1' )
                 I1(i,j,k) = 1;
            else
                 I1(i,j,k) = 0;
            end
                 
        end
    end
end


subplot(5,2,1),imshow(I);
subplot(5,2,2),imshow(I1(:,:,1));
subplot(5,2,3),imshow(I1(:,:,2));
subplot(5,2,4),imshow(I1(:,:,3));
subplot(5,2,5),imshow(I1(:,:,4));
subplot(5,2,6),imshow(I1(:,:,5));
subplot(5,2,7),imshow(I1(:,:,6));
subplot(5,2,8),imshow(I1(:,:,7));
subplot(5,2,9),imshow(I1(:,:,8));
