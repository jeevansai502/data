I1 = rgb2gray(imread('face.jpg'));
I2 = imread('image1_crop.jpg');

I = add(I1,I2);
imshow(I);