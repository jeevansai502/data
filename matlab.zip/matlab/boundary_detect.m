I = imread('seg_image.jpg');
level = graythresh(I);
BW = im2bw(I,level);

B = bwboundaries(BW);
  %       imshow(label2rgb(L, @jet, [.5 .5 .5]))
        imshow(I);
         hold on
         for k = 1:length(B)
             boundary = B{k};
             plot(boundary(:,2), boundary(:,1), 'r', 'LineWidth', 2)
         end