I = rgb2gray(imread('image1.jpg'));
[counts,binLocations] = imhist(I);
disp(sprintf('Intensity: %d  frequency: %d\n',h,bins));