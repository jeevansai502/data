s='jfvgnk';
disp(s);