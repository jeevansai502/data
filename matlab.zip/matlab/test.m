I = imread('image1.jpg');
[m,n] = size(I);


disp(I);