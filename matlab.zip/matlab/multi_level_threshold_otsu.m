I = imread('seg_image.jpg');
for n = 2:4
    IDX = otsu(I,n);
    figure, imagesc(IDX), axis image off
    title(['n = ' int2str(n)])
end
colormap(gray)