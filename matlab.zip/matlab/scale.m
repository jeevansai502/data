I = imread('face.jpg');
S = imresize(I,[256 256]);
imwrite(S,'face_scale.jpg');
