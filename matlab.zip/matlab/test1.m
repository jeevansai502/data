I1 = imread('damn-flag.png');
I2 = rgb2gray(imread('index.jpeg'));

[m,n] = size(I1);
rect1 = [0 0 m n];
I3 = imcrop(I2,rect1);

I = imsubtract(I1,I3);
disp(I);
