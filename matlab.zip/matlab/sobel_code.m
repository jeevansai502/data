I = rgb2gray(imread('face.jpg'));

M1 = [1 0 -1;2 0 -2;1 0 -1];
M2 = [1 2 1;0 0 0;-1 -2 -1];
%V1 = reshape(M1,1,numel(M1));
%V2 = reshape(M2,1,numel(M2));

%M = conv2(M1,M2)
%C1 = conv2(M,I);
%C = conv2(V2,V1,I);
%subplot(2,1,1),imshow(C);
%subplot(2,1,2),imshow(C1);

[m n] = size(I);

B = padarray(I,[1 1],'both');

Output1 = zeros([size(I,1) size(I,2)]);
 
for i = 1:1:m
    for j = 1:1:n
    
    %  Temp = B(i:i+2,j:j+2).*M1;
    C = B(i:i+2,j:j+2);  
    Temp = double(C).*M1;
   
    Output1(i,j) = sum(Temp(:));
   
    end
end

Output2 = zeros([size(I,1) size(I,2)]);
 
for i = 1:1:m
    for j = 1:1:n
    
    %  Temp = B(i:i+2,j:j+2).*M1;
    C = B(i:i+2,j:j+2);  
    Temp = double(C).*M2;
   
    Output2(i,j) = sum(Temp(:));
   
    end
end

Output = zeros([size(I,1) size(I,2)]);

for i = 1:1:m
    for j = 1:1:n
        
        Temp = sqrt( (Output1(i,j)*Output1(i,j)) + (Output2(i,j)*Output2(i,j)) );
        
        if Temp > 128
            Output(i,j) = 1;
        else
            Output(i,j) = 0;
        end
            
    end
end
    
imshow(Output);








