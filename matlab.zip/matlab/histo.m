I1 = imread('car.jpg');
arr1 = histogram_loop(I1);
bar(arr1);