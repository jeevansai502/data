I1 = rgb2gray(imread('fig1.jpg'));
I2 = rgb2gray(imread('fig2.jpg'));

A1 = imresize(I1,[266 403]);
A2 = imresize(I2,[266 403]);

disp(size(A1));
disp(size(A2));

Output = zeros(size(A1,1)+size(A1,2));

ind = 1;
for i = 1:1:size(A1,1)
    for j = 1:1:size(A1,2)        
        Output(ind) = round((A1(i,j) - A2(i,j)));
        ind = ind + 1;
    end
end

%disp(Output);

%Out = zeros(1,255);

%N1 = (Output - min(Output(:)))/(max(Output(:)) - min(Output(:))) * 255;

%disp(N1);
%for i = 1:1:(size(A1,1)+size(A1,2))

   %Out(N1(i)) = Out(N1(i)) + 1; 
    
%end

bar(Output);
%imhist(Output);

%bar(N1);

%bar(histogram_loop(N1));
