I = imread('seg_image.jpg');
level = graythresh(I);
BW = im2bw(I,level);
imshow(BW);
