function [ arr ] = histogram_loop( I )
%HISTOGRAM_LOOP Summary of this function goes here
%   Detailed explanation goes here

arr = zeros(1,256);
[m,n] = size(I);

for i = 1:m
    for j = 1:n
        
        val = I(i,j);
        arr(val + 1) = arr(val + 1) + 1;

    end
end

%{
for i = 1:256
   
   arr(i) = ((double(arr(i))*(m*n))/(255));
    
end


arr1 = zeros(1,256);

sum = 0;

for i = 1:256

    sum = 255*(sum + arr(i));
    arr1(i) = sum;
    
end
%}


