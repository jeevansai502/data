C = imread('Image_1.bmp');
B = [1 1 1;1 1 1;1 1 1];
%C = padarray(I,[0 1],1);
D = false(size(I));

for i=2:size(C,1)-1
    for j=2:size(C,2)-1

        In = C(i-1:i+1,j-1:j+1);
        M=[C(i-1,j-1) C(i-1,j) C(i-1,j+1) C(i,j-1) C(i,j) C(i,j+1) C(i+1,j-1) C(i+1,j) C(i+1,j+1)];
     %   if(In(In1) == 1)
      %      D(i,j) = max(In2);
      %  end
   
      D(i,j) = max(M);
      
    end
end

E = false(size(D));

for k=1:50

for i=2:size(C,1)-1
    for j=2:size(C,2)-1

        In = D(i-1:i+1,j-1:j+1);
        M=[D(i-1,j-1) D(i-1,j) D(i-1,j+1) D(i,j-1) D(i,j) D(i,j+1) D(i+1,j-1) D(i+1,j) D(i+1,j+1)];
     %   if(In(In1) == 1)
      %      D(i,j) = max(In2);
      %  end
   
        E(i,j) = max(M);
      
    end
end

reshape(D,size(E,1),size(E,2));

D = E(:,:);

end


subplot(2,1,1),imshow(imsubtract(E,C)),title('dilation');

for i=2:size(C,1)-1
    for j=2:size(C,2)-1

        In = C(i-1:i+1,j-1:j+1);
        M=[C(i-1,j-1) C(i-1,j) C(i-1,j+1) C(i,j-1) C(i,j) C(i,j+1) C(i+1,j-1) C(i+1,j) C(i+1,j+1)];
     %   if(In(In1) == 1)
      %      D(i,j) = min(In2);
      %  end
   
      D(i,j) = min(M);
      
    end
end

subplot(2,1,2),imshow(imsubtract(C,D)),title('erosion');