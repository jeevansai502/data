I = rgb2gray(imread('face_scale.jpg'));
BW = edge(I,'sobel');
imshow(BW);