function [ arr ] = add( I1,I2 )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%I = imadd(I1,I2);

[m,n] = size(I1); 

arr = zeros(m,n);

max = 0;
min = 99999999;

for i = 1:m
    for j = 1:n
        
        val1 = double(I1(i,j));
        val2 = double(I2(i,j));
        
        arr(i,j) = (val1 + val2)/(2*255);
        
        disp(val1);
        disp(val2);
        disp(arr(i,j));
        
        if arr(i,j) > max
            max = arr(i,j);
        end
        
        if arr(i,j) < min
            min = arr(i,j);
        end 
    end
end

disp( max);
disp( min);


end

