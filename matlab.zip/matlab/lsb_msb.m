I_msb = rgb2gray(imread('face.jpg'));
[m,n] = size(I_msb);

for y = 1:m
    for x = 1:n
        if I_msb(y,x)>127
            I_msb(y,x) = 255;
        else
            I_msb(y,x) = 0;
        end
    end
end

I_lsb = rgb2gray(imread('face.jpg'));

for y = 1:m
    for x = 1:n
        if (mod(I_lsb(y,x),2) == 0)
            I_lsb(y,x) = 0;
        else
            I_lsb(y,x) = 255;
        end
    end
end


subplot(2,2,1),imshow(I_msb);
arr1 = histogram_loop(I_msb);
subplot(2,2,2),bar(arr1);
subplot(2,2,3),imshow(I_lsb);
arr2 = histogram_loop(I_lsb);
subplot(2,2,4),bar(arr2);


    