I = rgb2gray(imread('face_scale.jpg'));
BW = edge(I,'log');
imshow(BW);