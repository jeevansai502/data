I = rgb2gray(imread('face.jpg'));
N = imnoise(I,'gaussian');
subplot(2,1,1),imshow(N);

D = filter2(fspecial('average',3),N)/255;
subplot(2,1,2),imshow(D)