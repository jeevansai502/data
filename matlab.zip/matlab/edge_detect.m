I = rgb2gray(imread('face_scale.jpg'));
h = fspecial('average',[3 3]);
%I = imfilter(I,h);

BW1 = edge(I,'prewitt');
BW2 = edge(I,'sobel');
BW3 = edge(I,'log');
BW4 = edge(I,'canny');

subplot(2,2,1),imshow(BW1),title('prewitt');

subplot(2,2,2),imshow(BW2),title('sobel');

subplot(2,2,3),imshow(BW3),title('log');
subplot(2,2,4),imshow(BW4),title('canny');