# PyFlooder
A [http flood](https://en.m.wikipedia.org/wiki/HTTP_Flood) python script that could stop a normal website in 10s

# How does it work ?
-It generates a random get requests and uees it to send to the target.

-By repeating this step for thousands of times in second the target stops :D

# Usage

```
pyflooder.py < Hostname > < Port > < Number_of_Attacks >
```
