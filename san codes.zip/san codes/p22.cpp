#include <bits/stdc++.h>
using namespace std;
#define PI  3.14159265
double rotatex(double x,double y){
	double angle = PI- atan(5)-acos(3/sqrt(26)) ;	return x*cos(angle)-y*sin(angle) ;
}
double rotatey(double x,double y){
	double angle = PI- atan(5)-acos(3/sqrt(26)) ;	return x*sin(angle)+y*cos(angle) ;
}
int main(){
	double l=11;
	double x11=11,y11=0,x12=12,y12=0,x13=12,y13=2,x14=11,y14=2;
	double x21=11,y21=2,x22=14,y22=2,x23=14,y23=3,x24=11,y24=3;
	double x31=14,y31=0,x32=15,y32=0,x33=15,y33=8,x34=14,y34=8;
	//transform
	 x11-=l,y11-=0,x12-=l,y12-=0,x13-=l,y13-=0,x14-=l,y14-=0;
	 x21-=l,y21-=0,x22-=l,y22-=0,x23-=l,y23-=0,x24-=l,y24-=0;
	 x31-=l,y31-=0,x32-=l,y32-=0,x33-=l,y33-=0,x34-=l,y34-=0;

	//rotation
	 double temp;
	 temp =x11;x11 = rotatex(x11,y11); y11 = rotatey(temp,y11);
	 temp =x12;x12 = rotatex(x12,y12); y12 = rotatey(temp,y12);
	 temp =x13;x13 = rotatex(x13,y13); y13 = rotatey(temp,y13);
	 temp =x14;x14 = rotatex(x14,y14); y14 = rotatey(temp,y14);
	 temp =x21;x21 = rotatex(x21,y21); y21 = rotatey(temp,y21);
	 temp =x22;x22 = rotatex(x22,y22); y22 = rotatey(temp,y22);
	 temp =x23;x23 = rotatex(x23,y23); y23 = rotatey(temp,y23);
	 temp =x24;x24 = rotatex(x24,y24); y24 = rotatey(temp,y24);
	 temp =x31;x31 = rotatex(x31,y31); y31 = rotatey(temp,y31);
	 temp =x32;x32 = rotatex(x32,y32); y32 = rotatey(temp,y32);
	 temp =x33;x33 = rotatex(x33,y33); y33 = rotatey(temp,y33);
	 temp =x34;x34 = rotatex(x34,y34); y34 = rotatey(temp,y34);

	 //transform
	 x11+=l,y11+=0,x12+=l,y12+=0,x13+=l,y13+=0,x14+=l,y14+=0;
	 x21+=l,y21+=0,x22+=l,y22+=0,x23+=l,y23+=0,x24+=l,y24+=0;
	 x31+=l,y31+=0,x32+=l,y32+=0,x33+=l,y33+=0,x34+=l,y34+=0;

	cout << x11 <<" "<< y11<<" "<<x12<<" "<<y12<<" "<<x13<<" "<<y13<<" "<<x14<<" "<<y14<<endl;
	cout << x21 <<" "<< y21<<" "<<x22<<" "<<y22<<" "<<x23<<" "<<y23<<" "<<x24<<" "<<y24<<endl;
	cout << x31 <<" "<< y31<<" "<<x32<<" "<<y32<<" "<<x33<<" "<<y33<<" "<<x34<<" "<<y34<<endl;

}