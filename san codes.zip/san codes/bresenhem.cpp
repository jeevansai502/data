void MidpointLine(int x1,y1,x2,y2)
{
	int dx=x2-x1;
	int dy=y2-y1;
	int d=2*dy-dx;
	int increE=2*dy;
	int incrNE=2*(dy-dx);
	x=x1;
	y=y1;
	WritePixel(x,y);
	while (x < x2) {
		if (d<= 0) {
			d+=incrE;
			x++
		} else {
			d+=incrNE;
			x++;
			y++;
		}
		WritePixel(x,y);
	}
}


