#include<iostream>
using namespace std;
void lineDDA (int xa, int ya, int xb, int yb)
{	
	int dx = xb - xa, dy = yb - ya, steps, k;
	float xIncrement, yIncrement, x = xa, y = ya;
	if ( abs(dx) > abs(dy) ) steps = abs (dx) ;
	else steps = abs (dy);
	xIncrement = dx / (float) steps;
	yIncrement = dy / (float) steps;
	
	cout<<(int)x<<" "<<(int)y<<endl;
	for (k=0; k<steps; k++) {
		x += xIncrment;
		y += yIncrement;
		cout<<(int)x<<" "<<(int)y<<endl;
	}
}


