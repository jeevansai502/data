#include<bits/stdc++.h>
using namespace std;
 
int main()
{
	
	int x0,y0,x1,y1;
	cout<<"enter left end pt ";
	cin>>x0>>y0;
	cout<<"Enter right end pt ";
	cin>>x1>>y1;
	int dx = x1 - x0, dy = y1 - y0, steps, k;
	float xIncrement, yIncrement, x = x0, y = y0;
	if(abs(dx) > abs(dy)) steps = abs(dx);
	else steps = abs(dy);
	xIncrement = dx / (float) steps;
	yIncrement = dy / (float) steps;
	cout << x << " " << y << endl;
	for(int k = 0; k < steps; k++){
		x += xIncrement;
		y += yIncrement;
		printf("%1.5f %1.5f\n", x, y);
	}
	return 0;
}
