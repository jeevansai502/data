#include<bits/stdc++.h>
using namespace std;
float max(float t1,float px)
{
	if(t1>px)
		return t1;
	else
		return px;
}
float min(float t2,float qx)
{
	if(t2<qx)
		return t2;
	else
		return qx;
}
int main()
{
    int x0,y0,xend,yend,xwmin,xwmax,ywmin,ywmax,i,p1,p2,p3,p4,q1,q2,q3,q4,x,y;
    float t0=0.0,t1=1.0;
    cin>>x0>>y0>>xend>>yend>>xwmin>>ywmin>>xwmax>>ywmax;
    p1=-(xend-x0);
    p2=(xend-x0);
    p3=-(yend-y0);
    p4=(yend-y0);
    q1=(x0-xwmin);
    q2=(xwmax-x0);
    q3=(y0-ywmin);
    q4=(ywmax-y0);
    int p[5]={p1,p2,p3,p4},q[5]={q1,q2,q3,q4};
    for(i=0;i<4;i++)
    	cout<< p[i] <<" "<< q[i] <<" "<< endl;
    for(i=0;i<4;i++)
    {
    	if(p[i]==0 && q[i]<0)
    		cout<<"Line Is Completely Outside"<<endl;
		else if(p[i]==0 && q[i]>=0)
			cout<<"Line Is Completely Inside"<<endl;
		else if(p[i]<0)
		{
			t0=max(t0,(float)q[i]/p[i]);
			cout<<" "<<t0 << endl;
		}	
		else if(p[i]>0)
		{
			t1=min(t1,(float)q[i]/p[i]);
			cout<<" "<<t1 <<endl;
		}
    }
    if(t0!=0)
	{
		x=x0+t0*(xend-x0);
		y=y0+t0*(yend-y0);
		cout<< x <<" "<< y <<endl;
	}
	else if(t1!=1)
	{
		x=x0+t1*(xend-x0);
		y=y0+t1*(yend-y0);
		cout<< x <<" "<< y << endl;
	}
	return 0;
}

