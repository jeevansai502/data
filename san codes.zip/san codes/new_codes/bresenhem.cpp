#include<bits/stdc++.h>
using namespace std;
 
int main()
{
	
	int x0,y0,x1,y1,p,dx,dy,i,x2,y2;
	cout<<"enter left end pt ";
	cin>>x0>>y0;
	cout<<"Enter right end pt ";
	cin>>x1>>y1;
	dx=(x1-x0);
	dy=(y1-y0);
	if(dx<dy)
	{
		y2=dx;
		dx=dy;
		dy=y2;
		x2=x0;
		y2=y0;
	}
	else
	{
		x2=y0;
		y2=x0;
	} 
	p=2*dy-dx;
	cout << x2 << " " << y2 << endl;
	for(i=x2;i<x1;i++)
	{
		if(p<=0)
		{
			x2++;
			p=p+2*dy;
		}
		else
		{
			x2++;
			y2++;
			p=p+2*dy-2*dx;
		}
		cout << x2 << " " << y2 << endl;
	}
	return 0;
}
