#include<bits/stdc++.h>
using namespace std;


void Draw(int x,int y,int xC,int yC)
{
	cout << xC+x << " " << yC+y << endl;
	cout << xC+x << " " << yC-y << endl;
    cout << xC-x << " " << yC+y << endl;
    cout << xC-x << " " << yC-y << endl;
    cout << xC+y << " " << yC+x << endl;
    cout << xC-y << " " << yC+x << endl;
    cout << xC+y << " " << yC-x << endl;
    cout << xC-y << " " << yC-x << endl;
}

void Circle(int Radius,int xC,int yC)
{
    int P;
    int x,y;
    void Draw(int x,int y,int xC,int yC);
    P = 1 - Radius;
    x = 0;
    y = Radius;
    Draw(x,y,xC,yC);
    while (x<=y)
    {
        x++;
        if (P<0)
        {
            P += 2 * x + 1;
        }
        else
        {
            P += 2 * (x - y) + 1;
            y--;
        }
        Draw(x,y,xC,yC);
    }

}

int main()
{
    int Radius, xC, yC;
    cout<< endl << "Enter Center point coordinates...";
    cout<<endl<<"  Xc    : ";
    cin>>xC;
    cout<<endl<<"  Xc    : ";
    cin>>yC;
    cout<<endl<<"Radius  : ";
    cin>>Radius;
    Circle(Radius,xC,yC);
    return 0;
}

