#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int xmin,xmax,ymin,ymax;
int n;
vector<float> corx,cory;
vector<float> tmpx,tmpy;
vector<float>::iterator it;
void clipl()
{
	float x,y,a,b;
	for(int i=0;i<corx.size();i++)
	{
	//	test(corx[i],cory[i],corx[i+1],cory[i+1],xmin);
		x = corx[i];
		y = cory[i];
		a = corx[(i+1)%corx.size()];
		b = cory[(i+1)%cory.size()];
		float m = (b-y)/(a-x);
		if(x>=xmin && a>=xmin)
		{
		/*	if(x==xmin)
			{
				tmpx.push_back(x);
				tmpy.push_back(y);
			}*/
			tmpx.push_back(a);
			tmpy.push_back(b);
		}
		else if(x<=xmin && a<=xmin)
		{
			if(a==xmin)
			{
				tmpx.push_back(a);
				tmpy.push_back(b);
			}
		//	continue;
		}
		else if(x<xmin && a>xmin)
		{
			x = xmin;
			y = b + m*(x-a);
				tmpx.push_back(x);
				tmpx.push_back(a);
				tmpy.push_back(y);
				tmpy.push_back(b);
		}
		else if(x>xmin && a<xmin)
		{
			a = xmin;
			b = y+ m*(a-x);
				tmpx.push_back(a);
				tmpy.push_back(b);
		}
		
	}
	corx.clear();
	cory.clear();
	for(int i=0;i<tmpx.size();i++)
	{
		corx.push_back(tmpx[i]);
		cory.push_back(tmpy[i]);
	}
}
void clipr()
{
	float x,y,a,b;
	for(int i=0;i<corx.size();i++)
	{
	//	test(corx[i],cory[i],corx[i+1],cory[i+1],xmin);
		x = corx[i];
		y = cory[i];
		a = corx[(i+1)%corx.size()];
		b = cory[(i+1)%cory.size()];
		float m = (b-y)/(a-x);
		if(x<=xmax && a<=xmax)
		{
		/*	if(x==xmax)
			{
				tmpx.push_back(x);
				tmpy.push_back(y);
			}*/
			tmpx.push_back(a);
			tmpy.push_back(b);
		}
		else if(x>=xmax && a>=xmax)
		{
			if(a==xmax)
			{
				tmpx.push_back(a);
				tmpy.push_back(b);
			}
		//	continue;
		}
		else if(x<xmax && a>xmax)
		{
			a = xmax;
			b = y + m*(a-x);
			tmpx.push_back(a);
			tmpy.push_back(b);
		}
		else if(x>xmax && a<xmax)
		{
			x = xmax;
			y = b + m*(x-a);
			tmpx.push_back(x);
			tmpy.push_back(y);
			tmpx.push_back(a);
			tmpy.push_back(b);
		}
	}
	corx.clear();
	cory.clear();
	for(int i=0;i<tmpx.size();i++)
	{
		corx.push_back(tmpx[i]);
		cory.push_back(tmpy[i]);
	}
}
void clipb()
{
	float x,y,a,b;
	for(int i=0;i<corx.size();i++)
	{
	//	test(corx[i],cory[i],corx[i+1],cory[i+1],xmin);
		x = corx[i];
		y = cory[i];
		a = corx[(i+1)%corx.size()];
		b = cory[(i+1)%cory.size()];
		float m = (b-y)/(a-x);
		if(y>=ymin && b>=ymin)
		{
		/*	if(y==ymin && b>ymin)
			{
				tmpx.push_back(x);
				tmpy.push_back(y);
			}*/
			tmpx.push_back(a);
			tmpy.push_back(b);
		}
		else if(y<=ymin && b<=ymin)
		{
			if(b==ymin)
			{
				tmpx.push_back(a);
				tmpy.push_back(b);
			}
		//	continue;
		}
		else if(y>ymin && b<ymin)
		{
			if(a-x==0)
			{
				b = ymin;
			}
			else
			{
				b = ymin;
				a = (b - y + m*x)/m;
			}
			tmpx.push_back(a);
			tmpy.push_back(b);
		}
		else if(y<ymin && b>ymin)
		{
			if(a-x==0)
			{
				y = ymin;
			}
			else
			{
				y = ymin;
				x = (y - b +m*a)/m;
			}
			tmpx.push_back(x);
			tmpy.push_back(y);
			tmpx.push_back(a);
			tmpy.push_back(b);
		}
		
	}
	corx.clear();
	cory.clear();
	for(int i=0;i<tmpx.size();i++)
	{
		corx.push_back(tmpx[i]);
		cory.push_back(tmpy[i]);
	}
}
void clipt()
{
	float x,y,a,b;
	for(int i=0;i<corx.size();i++)
	{
	//	test(corx[i],cory[i],corx[i+1],cory[i+1],xmin);
		x = corx[i];
		y = cory[i];
		a = corx[(i+1)%corx.size()];
		b = cory[(i+1)%cory.size()];
		float m = (b-y)/(a-x);
		if(y<=ymax && b<=ymax)
		{
		/*	if(y==ymax && b!=ymax)
			{
				tmpx.push_back(x);
				tmpy.push_back(y);
			}*/
			tmpx.push_back(a);
			tmpy.push_back(b);
		}
		else if(y>=ymax && b>=ymax)
		{
			if(b==ymax)
			{
				tmpx.push_back(a);
				tmpy.push_back(b);
			}
		//	continue;
		}
		else if(y<ymax && b>ymax)
		{
			if(a-x==0)
			{
				b = ymax;
			}
			else
			{
				b = ymax;
				a = (b - y + m*x)/m;
			}
			tmpx.push_back(a);
			tmpy.push_back(b);
		}
		else if(y>ymax && b<ymax)
		{
			if(a-x==0)
			{
				y = ymax;
			}
			else
			{
				y = ymax;
				x = (y - b +m*a)/m;
			}
			tmpx.push_back(x);
			tmpy.push_back(y);
			tmpx.push_back(a);
			tmpy.push_back(b);
		}
		
	}
	corx.clear();
	cory.clear();
	for(int i=0;i<tmpx.size();i++)
	{
		corx.push_back(tmpx[i]);
		cory.push_back(tmpy[i]);
	}
}
void hodgman()
{
	clipl();
	tmpx.clear();
	tmpy.clear();
	for(int i=0;i<corx.size();i++)
	{
		cout<<"("<<corx[i]<<","<<cory[i]<<")"<<" ";
	}
	cout<<endl;
	clipr();
	tmpx.clear();
	tmpy.clear();
	for(int i=0;i<corx.size();i++)
	{
		cout<<"("<<corx[i]<<","<<cory[i]<<")"<<" ";
	}
	cout<<endl;
	clipb();
	tmpx.clear();
	tmpy.clear();
	for(int i=0;i<corx.size();i++)
	{
		cout<<"("<<corx[i]<<","<<cory[i]<<")"<<" ";
	}
	cout<<endl;
	clipt();
	tmpx.clear();
	tmpy.clear();
	cout<<"Final coordinates are : ";
	for(int i=0;i<corx.size();i++)
	{
		cout<<"("<<corx[i]<<","<<cory[i]<<")"<<" ";
	}
}

int main()
{
	int x,y;
	cout<<"Enter polygon coordinates in anticlockwise direction (-1,-1 to exit ) : ";
	n=0;
	while(1)
	{
		cin>>x>>y;
		if(x==-1 && y==-1)
		{
			break;
		}
		corx.push_back(x);
		cory.push_back(y);
		n++;
	}
	cout<<"enter xmin ,xmax,ymin,ymax : ";
	cin>>xmin>>xmax>>ymin>>ymax;
	hodgman();
	return 0;
}
