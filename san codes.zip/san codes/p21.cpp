#include <bits/stdc++.h>
using namespace std;
double rectarea(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4){
	return abs(0.5*(x1*y2+x2*y3+x3*y4+x4*y1-y1*x2-y2*x3-y3*x4-y4*x1));
}
double triarea(double x1,double y1,double x2,double y2,double x3,double y3){
		return abs(0.5*(x1*y2+x2*y3+x3*y1-y1*x2-y2*x3-y3*x1));
}

bool iftable(double x,double y){
	double x11=3,y11=0,x12=4,y12=0,x13=4,y13=4,x14=3,y14=4;
	double x21=8,y21=0,x22=9,y22=0,x23=9,y23=4,x24=8,y24=4;
	double x31=2,y31=4,x32=10,y32=4,x33=10,y33=5,x34=2,y34=5;
	double area11,area12,area13,area21,area22,area23,area31,area32,area33,area14,area24,area34,recarea1,recarea2,recarea3;
	area21 = triarea(x,y,x21,y21,x22,y22);
	area22 = triarea(x,y,x22,y22,x23,y23);
	area23 = triarea(x,y,x23,y23,x24,y24);
	area24 = triarea(x,y,x24,y24,x21,y21);
	recarea2 = rectarea(x21,y21,x22,y22,x23,y23,x24,y24);

	area11 = triarea(x,y,x11,y11,x12,y12);
	area12 = triarea(x,y,x12,y12,x13,y13);
	area13 = triarea(x,y,x13,y13,x14,y14);
	area14 = triarea(x,y,x14,y14,x11,y11);
	recarea1 = rectarea(x11,y11,x12,y12,x13,y13,x14,y14);

	area31 = triarea(x,y,x31,y31,x32,y32);
	area32 = triarea(x,y,x32,y32,x33,y33);
	area33 = triarea(x,y,x33,y33,x34,y34);
	area34 = triarea(x,y,x34,y34,x31,y31);
	recarea3 = rectarea(x31,y31,x32,y32,x33,y33,x34,y34);
	if (abs(area11+area12+area13+area14 - recarea1) <= 0.000000001){
		cout <<"IEEE"<<endl;
		return true;
	}
	if (abs((area21+area22+area23+area24) - recarea2) <= 0.000000001)
	{
		cout <<"IEEE"<<endl;
		return true;
	}
	if (abs(area31+area32+area33+area34 - recarea3) <= 0.000000001)
	{
		cout <<"IEEE"<<endl;
		return true;
	}
	return false;
}
bool ifchair(double x,double y){
	double x11=11,y11=0,x12=12,y12=0,x13=12,y13=2,x14=11,y14=2;
	double x21=11,y21=2,x22=14,y22=2,x23=14,y23=3,x24=11,y24=3;
	double x31=14,y31=0,x32=15,y32=0,x33=15,y33=8,x34=14,y34=8;
	double area11,area12,area13,area21,area22,area23,area31,area32,area33,area14,area24,area34,recarea1,recarea2,recarea3;
	area21 = triarea(x,y,x21,y21,x22,y22);
	area22 = triarea(x,y,x22,y22,x23,y23);
	area23 = triarea(x,y,x23,y23,x24,y24);
	area24 = triarea(x,y,x24,y24,x21,y21);
	recarea2 = rectarea(x21,y21,x22,y22,x23,y23,x24,y24);

	area11 = triarea(x,y,x11,y11,x12,y12);
	area12 = triarea(x,y,x12,y12,x13,y13);
	area13 = triarea(x,y,x13,y13,x14,y14);
	area14 = triarea(x,y,x14,y14,x11,y11);
	recarea1 = rectarea(x11,y11,x12,y12,x13,y13,x14,y14);

	area31 = triarea(x,y,x31,y31,x32,y32);
	area32 = triarea(x,y,x32,y32,x33,y33);
	area33 = triarea(x,y,x33,y33,x34,y34);
	area34 = triarea(x,y,x34,y34,x31,y31);
	recarea3 = rectarea(x31,y31,x32,y32,x33,y33,x34,y34);
	if (abs(area11+area12+area13+area14 - recarea1) <= 0.0000001){
		cout <<"RAS"<<endl;
		return true;
	}
	if (abs(area21+area22+area23+area24 - recarea2) <= 0.0000001)
	{
		cout <<"RAS"<<endl;
		return true;
	}
	if (abs(area31+area32+area33+area34 - recarea3) <=0.0000001)
	{
		cout <<"RAS"<<endl;
		return true;
	}
	return false;
}
int main(){
	int n=500;
	double x,y;
	bool a,b;
	for (int i = 0; i < n; ++i)
	{
		cin >> x >> y;
		a = iftable(x,y);
		if(!a){
		b = ifchair(x,y);			
		}
		if (!a && !b)
		{
			cout << "ACM" << endl;
		}
	}
}