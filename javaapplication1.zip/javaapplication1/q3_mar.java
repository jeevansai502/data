/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javaapplication1.q2.con;
import static javaapplication1.q2.ps;
import javax.swing.JFrame;
import javax.swing.JTable;

/**
 *
 * @author placements2017
 */
public class q3_mar implements ActionListener{

    q3_mar(JFrame f) {
        f.dispose();
    }
    
     String query;
    PreparedStatement ps;
    ResultSet rs;
    Connection con;
    JFrame f1; 
    JTable t; 
    
    @Override
    public void actionPerformed(ActionEvent e) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","iiita");
            
            query = "select * from marks";
            
            ps = con.prepareStatement(query);
            
            rs = ps.executeQuery();
            
              f1 = new JFrame("Marks"); 
            
           f1.setSize(500, 500);
           f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
              Vector<Vector<String>> l = new Vector<Vector<String>>();
            
             while(rs.next()){
               
                 String id,subject;
                 int test;
                 double marks;
                 
                 id = rs.getString("id");
                 subject = rs.getString("subject");
                 test = rs.getInt("test");
                 marks = rs.getDouble("marks");
                 
               Vector<String> l1 = new Vector<String>();
                l1.add(id);
                l1.add(subject);
                l1.add(Integer.toString(test));
                l1.add(Double.toString(marks));
                l.add(l1);
            
           }
             
              Vector<String> col = new Vector<String>(); 
           col.add("id");
           col.add("subject");           
           col.add("test"); 
           col.add("marks");
            
            t = new JTable(l,col);
           f1.add(t);  
            
           f1.setVisible(true);  
            
        } catch (Exception ex) {
           ex.printStackTrace();
        }
            

    }
    
}
