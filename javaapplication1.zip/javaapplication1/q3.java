/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.*;
import javax.swing.*;
/**
 *
 * @author placements2017
 */
public class q3 {
    
      void fun(){
            
        JPanel p1,p2,p3,p;
        JFrame f1;
        JLabel l1,l2,l3;
        JTextField t1;
        JPasswordField t2;
        JButton b1;
        
        f1 = new JFrame("Login");
       
        f1.setSize(600, 300);
        f1.setLayout(null);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        l1 = new JLabel("Email :");
      
        l2 = new JLabel("Password :");
      
        l3 = new JLabel("Login:");
        l3.setForeground(Color.blue);

        l3.setFont(new Font("Serif", Font.BOLD, 20));
        t1 = new JTextField();
          
        t2 = new JPasswordField();
     
        b1 = new JButton("Login");        
       
        
        l3.setBounds(100, 30, 400, 30);

        l1.setBounds(80, 70, 200, 30);

        l2.setBounds(80, 110, 200, 30);
        
        t1.setBounds(300, 70, 200, 30);

        t2.setBounds(300, 110, 200, 30);

        b1.setBounds(150, 160, 100, 30);
        b1.addActionListener(new q3_button(f1,t1,t2));
        
        f1.add(l3);
        f1.add(l1);
        f1.add(l2);
        f1.add(t1);
        f1.add(t2);
        f1.add(b1); 
        f1.setVisible(true);
    }
    
   
        public static void main(String args[]) {
        
             new q3().fun();        
        }
}
