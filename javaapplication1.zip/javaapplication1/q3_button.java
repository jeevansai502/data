/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javaapplication1.q2.con;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author placements2017
 */
public class q3_button implements ActionListener{

    JFrame f1,f;
    JPanel p;
    JTextField t1;
    JPasswordField t2;
    String query;
    PreparedStatement ps;
    ResultSet rs;
    Connection con;
    String st, pass,user;
    q3_button(JFrame f1, JTextField t1, JPasswordField t2) {
        this.t1 = t1;
        this.t2 = t2;
        this.f1 = f1;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        
        try {
            user = t1.getText();
            pass = new String(t2.getPassword());
         
            Class.forName("com.mysql.jdbc.Driver");
            
            query = "select password from login where username=?";
            
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "iiita"); 

            ps = con.prepareStatement(query);
            ps.setString(1, user);
            rs = ps.executeQuery();
           
            
            if(!rs.next()){
              
                JOptionPane.showMessageDialog(null, "No user with the specified email exists");
            }
            
            rs.previous();
            
            if(rs.next()){
                st = rs.getString("password");
            }
            
            if(!st.equals(pass)){
                JOptionPane.showMessageDialog(null, "Wrong Password");
            }else{
                
                f = new JFrame("Records");
                p = new JPanel(new GridBagLayout());
                f.setSize(600, 300);
                f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
                JButton b1,b2;
                
                b1 = new JButton("Attendance Records");
                b2 = new JButton("Marks Records");
                
                
        
                b1.addActionListener(new q3_att(f));
       
                b2.addActionListener(new q3_mar(f));
                b1.setSize(50, 50);
                b2.setSize(50, 50);
                
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.gridx = 0;
                gbc.gridy = 0;
                
                
                p.add(b1,gbc);
                
                gbc.gridx = 5;
                gbc.gridy = 0;
                
             
                p.add(b2,gbc);
                f.add(p);
                f.setVisible(true);
                f1.dispose();
        
            }
            
            
        } catch (Exception ex) {
           ex.printStackTrace();
        } 
   
    
}

}