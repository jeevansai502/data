/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.io.*;
import java.util.*;
import java.lang.*;
import java.text.*;
import java.math.*;

/**
 *
 * @author placements2017
 */

class node implements Comparable < node > {

	int x;
	int y;
	int dir;
	int cost;
	Long timestamp = System.nanoTime();

	node(int x, int y, int dir, int cost) {
		this.x = x;
		this.y = y;
		this.dir = dir;
		this.cost = cost;
	}

	public int compareTo(node o) {

		if (o.cost == cost)
			return timestamp.compareTo(o.timestamp);
		else {
			int d = cost - o.cost;
			if (d > 0)
				return 1;
			else
				return -1;
		}
	}

}

public class Ideone {
	
	Scanner sc;
	static int[][] arr;
	static int sx, sy, found = 0, m, n, t, dx, dy;
	static double d = Math.sqrt(2);
	static int rt2, r1 = 10000;
	static PriorityQueue < node > p;
	static Map < node, node > map;
	public static int[][] cost;
        static node dn;
        
	static void print(node nd) {

		if (map.containsKey(nd)) {
			nd = map.get(nd);
                        print(nd);
			System.out.print(nd.x + " " + nd.y + " ");
		}

	}
	static int get(int s, int c) {

		int v = Math.abs(s - c);

		if (v <= 4) {
			return v;
		} else {
			return 8 - v;
		}

	}

	static void fun(node nd, int cst) {

		int x, y;

		x = nd.x;
		y = nd.y;

		if (arr[x][y] == 1) {

			found = 1;
                        print(nd);
			dx = x;
			dy = y;
 
                        System.out.println("-----------------------");
                        while(p.size() != 0){
                            
                            node nx = p.poll();
                              System.out.println(nx.x + " " + nx.y + " " + nx.cost + " " + nx.dir);
                                }
//print(nd);
			return;
		}

		if (y + 1 < n) {
			if (arr[x][y + 1] != -1) {

				int c;

				if (nd.dir == 1) {
					c = cst + r1;
				} else {
					int v = get(nd.dir, 1);
					c = cst + (v) * r1 * 5 + r1;
				}

				node n1 = new node(x, y + 1, 1, c);

				if (cost[x][y + 1] == -1 || cost[x][y + 1] > c) {
					cost[x][y + 1] = c;
					p.add(n1);
	                                System.out.println(n1.x + " " + n1.y + " " + n1.cost + " " + n1.dir);
                                        map.put(n1, nd);
				}
			}
		}

		if (y + 1 < n && x + 1 < m) {
			if (arr[x + 1][y + 1] != -1) {

				int c;

				if (nd.dir == 2) {
					c = cst + rt2;
				} else {
					int v = get(nd.dir, 2);
					c = cst + (v) * r1 * 5 + rt2;
				}
				node n1 = new node(x + 1, y + 1, 2, c);

				if (cost[x + 1][y + 1] == -1 || cost[x + 1][y + 1] > c) {
					cost[x + 1][y + 1] = c;
					p.add(n1);
		                	System.out.println(n1.x + " " + n1.y + " " + n1.cost + " " + n1.dir);
                                        map.put(n1, nd);
				}
			}
		}

		if (x + 1 < m) {
			if (arr[x + 1][y] != -1) {

				int c;

				if (nd.dir == 3) {
					c = cst + r1;
				} else {
					int v = get(nd.dir, 3);
					c = cst + (v) * r1 * 5 + r1;
				}
				node n1 = new node(x + 1, y, 3, c);

				if (cost[x + 1][y] == -1 || cost[x + 1][y] > c) {
					cost[x + 1][y] = c;
					p.add(n1);
                 			System.out.println(n1.x + " " + n1.y + " " + n1.cost + " " + n1.dir);
                                        map.put(n1, nd);
				}
			}
		}

		if (y - 1 >= 0 && x + 1 < m) {
			if (arr[x + 1][y - 1] != -1) {

				int c;

				if (nd.dir == 4) {
					c = cst + rt2;
				} else {
					int v = get(nd.dir, 4);
					c = cst + (v) * r1 * 5 + rt2;
				}
				node n1 = new node(x + 1, y - 1, 4, c);

				if (cost[x + 1][y - 1] == -1 || cost[x + 1][y - 1] > c) {
					cost[x + 1][y - 1] = c;
					p.add(n1);
					System.out.println(n1.x + " " + n1.y + " " + n1.cost + " " + n1.dir);
                                        map.put(n1, nd);
				}
			}
		}

		if (y - 1 >= 0) {
			if (arr[x][y - 1] != -1) {

				int c;

				if (nd.dir == 5) {
					c = cst + r1;
				} else {
					int v = get(nd.dir, 5);
					c = cst + (v) * r1 * 5 + r1;
				}
				node n1 = new node(x, y - 1, 5,c);

				if (cost[x][y - 1] == -1 || cost[x][y - 1] > c) {
					cost[x][y - 1] = c;
					p.add(n1);
					System.out.println(n1.x + " " + n1.y + " " + n1.cost + " " + n1.dir);
                                        map.put(n1, nd);
				}
			}
		}

		if (y - 1 >= 0 && x - 1 >= 0) {
			if (arr[x - 1][y - 1] != -1) {

				int c;

				if (nd.dir == 6) {
					c = cst + rt2;
				} else {
					int v = get(nd.dir, 6);
					c = cst + (v) * r1 * 5 + rt2;
				}
				node n1 = new node(x - 1, y - 1, 6,c);

				if (cost[x - 1][y - 1] == -1 || cost[x - 1][y - 1] > c) {
					cost[x - 1][y - 1] = c;
					p.add(n1);
					System.out.println(n1.x + " " + n1.y + " " + n1.cost + " " + n1.dir);
                                        map.put(n1, nd);
				}
			}
		}

		if (x - 1 >= 0) {
			if (arr[x - 1][y] != -1) {

				int c;

				if (nd.dir == 7) {
					c = cst + r1;
				} else {
					int v = get(nd.dir, 7);
					c = cst + (v) * r1 * 5 + r1;
				}

				node n1 = new node(x - 1, y, 7,c);
				if (cost[x - 1][y] == -1 || cost[x - 1][y] > c) {
					cost[x - 1][y] = c;
					p.add(n1);
					System.out.println(n1.x + " " + n1.y + " " + n1.cost + " " + n1.dir);
                                        map.put(n1, nd);
				}
			}
		}

		if (y + 1 < n && x - 1 >= 0) {
			if (arr[x - 1][y + 1] != -1) {

				int c;

				if (nd.dir == 8) {
					c = cst + rt2;
				} else {
					int v = get(nd.dir, 8);
					c = cst + (v) * r1 * 5 + rt2;
				}
				node n1 = new node(x - 1, y + 1, 8,c);

				if (cost[x - 1][y + 1] == -1 || cost[x - 1][y + 1] > c) {
					cost[x - 1][y + 1] = c;
					p.add(n1);
					System.out.println(n1.x + " " + n1.y + " " + n1.cost + " " + n1.dir);
                                        map.put(n1, nd);
				}
			}
		}

		node no = p.poll();
		 System.out.println();
                System.out.println(no.x + " " + no.y + " " + no.cost + " " + no.dir);
               
                fun(no, no.cost);

		if (found == 1) {
			return;
		}

	}
	
	public static void main(String args[]) throws Exception {

		Scanner sc = new Scanner(System.in);

		t = sc.nextInt();

		for (int i = 0; i < t; i++) {

			m = sc.nextInt();
			n = sc.nextInt();

			arr = new int[m][n];
			cost = new int[m][n];

			for (int j = 0; j < m; j++) {
				for (int k = 0; k < n; k++) {
					arr[j][k] = sc.nextInt();
				}
			}

			DecimalFormat df = new DecimalFormat("#.####");
		//	rt2 = (int)(Double.parseDouble(df.format(d)) * 10000);
                        rt2 = 10000;
                
			for (int[] row: cost)
				Arrays.fill(row, -1);

			sx = sc.nextInt();
			sy = sc.nextInt();

			if (arr[sx][sy] == 1) {
				found = 1;
				System.out.println(sx + " " + sy + " ");
				return;
			}

			cost[sx][sy] = 0;

			p = new PriorityQueue < node > ();
			map = new HashMap < > ();

			fun(new node(sx, sy, 1, 0), 0);

			System.out.println(dx + " " + dy + " ");
		}
	}
}
