/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.io.*;
import java.lang.*;

/**
 *
 * @author placements2017
 */
public class q1 {
    
    static BufferedReader br;
    
    
    private static String readFileAsString(String inp) throws FileNotFoundException, IOException {
    
        StringBuffer sb;
        sb = new StringBuffer();
        br = new BufferedReader(new FileReader(inp));
        char[] buf = new char[1024]; 
        int numRead =0;
    
        while((numRead = br.read(buf)) != -1){
        String readData = String.valueOf(buf, 0,numRead );
        sb.append(readData);
        }
        br.close();
        return sb.toString();
    
    }
    
    public static void main(String[] args) throws FileNotFoundException, IOException{
    
        
        String text = readFileAsString("/home/placements2017/input.c");
           
        
        
        
        
    }

    
    
}
