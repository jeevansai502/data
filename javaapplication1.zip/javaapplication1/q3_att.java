/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.lang.*;
import java.io.*;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.JTableHeader;
/**
 *
 * @author placements2017
 */
public class q3_att implements ActionListener{

    String query;
    PreparedStatement ps;
    ResultSet rs;
    Connection con;
    JFrame f1; 
    JTable t;
    Object obj[][];
    
    q3_att(JFrame f) {
        f.dispose();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","iiita");
            
            query = "select * from attendance";
            
            ps = con.prepareStatement(query);
            
            rs = ps.executeQuery();
            
           f1 = new JFrame("Attendance"); 
            
           f1.setSize(500, 500);
             f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
           
          Vector<Vector<String>> l = new Vector<Vector<String>>();
           
       
             while(rs.next()){
               
                 String id,subject;
                 double attendance;
                 
                 id = rs.getString("id");
                 subject = rs.getString("subject");
                 attendance = rs.getDouble("attendance");
                 
                Vector<String> l1 = new Vector<String>();
                l1.add(id);
                l1.add(subject);
                l1.add(Double.toString(attendance));
                l.add(l1);
            
           }
          
           Vector<String> col = new Vector<String>(); 
           col.add("id");
           col.add("subject");
           col.add("attendance");
          
           t = new JTable(l,col);
           t.setCellSelectionEnabled(true);
           t.getColumnModel().getSelectionModel().addListSelectionListener(new ListSelectionListener()
            {
                public void valueChanged(ListSelectionEvent ev)
                {
                    int row = 0,column = 0;
                    boolean v = ev.getValueIsAdjusting(); 
                    if(v == false){
                         row = t.getSelectedRow();
                         column = t.getSelectedColumn();
                                    
                    }
                    String value = null;
                    double val = 0;
                    int i;

                    
                   i = Integer.parseInt((String) t.getModel().getValueAt(row, 0));
                    
                   
                    if(column == 1 && v==false){
                    value =  (String) t.getModel().getValueAt(row, column);
                    System.out.println(value);
                    }else if(column == 2 && v==false){
                    val = Double.parseDouble((String) t.getModel().getValueAt(row, column));
                    System.out.println(val);
                    }
                    
                    if(column == 1){
                        try {
                            query = "update attendance set subject=? where id=?";
                            ps = con.prepareStatement(query);
                            ps.setString(1, value);
                            ps.setInt(2, i);
                           
                            ps.executeUpdate();
                        } catch (SQLException ex) {
                            Logger.getLogger(q3_att.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    
                    }else if(column == 2){
                    query = "update attendance set attendance=? where id=?";
                    try {
                        ps = con.prepareStatement(query);
                        ps.setDouble(1, val);
                        ps.setInt(2, i);
                        ps.executeUpdate();
                        
                    } catch (SQLException ex) {
                        Logger.getLogger(q3_att.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    }
                     
                } 
            });
     
           JScrollPane scrollpane = new JScrollPane(t);     
           f1.add(scrollpane);
    
        }catch (Exception ex) {
            ex.printStackTrace();
        }
                 
         f1.setVisible(true);
        
    }
    
}
