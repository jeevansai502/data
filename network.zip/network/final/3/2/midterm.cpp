#include<bits/stdc++.h>
#define st sqrt(5)
#define e 0.00001
using namespace std;
int graph[8][8];
typedef pair <int, int> p;
struct great{
	bool operator()(const pair < p, double >& left, const pair < p, double >& right){
		return left.second > right.second;
	}
};
priority_queue < pair < p, double>, vector < pair <p , double> >, great > pq;
int flag, err;
map < p, p > mp;
map < p, double > mp2;
p child, dest, parent;
void actions(int i, int j, double dist){
	child = make_pair(i, j);
	if(i>=0 && i<8 && j>=0 && j<8){
	if((graph[i][j] != 1 && (graph[i][j]==2 || !( i-1>=0 && j-1>=0 && graph[i-1][j-1] == 1) && !(i-1>=0 && j+1<8 && graph[i-1][j+1		] == 1) ) ) ){	
			if(graph[i][j] == 2){
				dest = make_pair(i, j);
				flag = 1;
			}
			if(mp.find(child) == mp.end()){
				mp[child] = parent;
				mp2[child] = dist;
				pq.push(make_pair(child, dist));
			}else{
				if(dist < mp2[child]){
					mp2[child] = dist;
					mp[child] = parent;
					pq.push(make_pair(child, dist));
				}
			}
		}
	}
}
void dijks(p src){
	mp[src] = src;
	mp2[src] = 0;
	pq.push(make_pair(src, 0));
	while(!pq.empty()){
		int i = pq.top().first.first;
		int j = pq.top().first.second;
		double dist = pq.top().second;
		parent = make_pair(i, j);
		pq.pop();
		actions(i-2, j-1, dist+st+(err++)*e);
		actions(i-2, j+1, dist+st+(err++)*e);
		actions(i-1, j-2, dist+st+(err++)*e);
		actions(i-1, j+2, dist+st+(err++)*e);
		actions(i+1, j-2, dist+st+(err++)*e);
		actions(i+1, j+2, dist+st+(err++)*e);
		actions(i+2, j-1, dist+st+(err++)*e);
		actions(i+2, j+1, dist+st+(err++)*e);
	}
}
int main(){
	int t;
	cin >> t;
	while(t--){
		err = 0, flag = 0;
		int x, y;
		cin >> x >> y;
		int m;
		cin >> m;
		for(int i=0; i<8; i++){
			for(int j=0; j<8; j++){
				cin >> graph[i][j];
			}
		}
		p src = make_pair(x, y);
		dijks(src);
		if(!flag){
			cout << "no solution" << endl;
			mp.clear();
			mp2.clear();
			while(!pq.empty()){
				pq.pop();
			}
			continue;
		}
		stack <p> s;
		while(dest != src){
			s.push(dest);
			dest = mp[dest];
		}
		if(m==0){
			cout << s.size() << endl;
		}else if(m==1){
		cout << src.first << " " << src.second << endl;
		while(!s.empty()){
			cout << s.top().first << " " << s.top().second << endl;
			s.pop();
		}
		cout << "end" << endl;
		}
		mp.clear();
		mp2.clear();
		while(!pq.empty()){
			pq.pop();
		}
	}
	return 0;
}
