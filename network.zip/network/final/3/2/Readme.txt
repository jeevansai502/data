1. go to current directory in which these programs are is contained while compiling.
2. compile and execute these programs in different terminals as shown in q2.png.

3. compile and execute server program as:
	gcc server.c
	./a.out [port no]

4. compile and execute client program as:
	gcc client.c
	./a.out 127.0.0.1 [same port no as in server terminal]

5. File will be sent if requested file is available with server and file received will be noticed on server side. If file is not available then "No such file or directory" will be received by client
