1. go to current directory in which these programs are is contained while compiling.
2. compile and execute these programs in different terminals as shown in q3.png.

3. compile and execute server program as:
	gcc server.c -pthread
	./a.out [port no]

4. compile and execute client program as:
	gcc client.c -pthread
	./a.out 127.0.0.1 [same port no as in server terminal]

5. Now, we can have non blocking chat facility to the users.


