1. go to current directory in which these programs are is contained while compiling.
2. compile and execute these programs in different terminals as shown in q1.png.

3. compile and execute server program as:
	gcc server.c
	./a.out [port no]

4. compile and execute client program as:
	gcc client.c
	./a.out 127.0.0.1 [same port no as in server terminal]

5. Now, messages are exchanged as a protocol given.
