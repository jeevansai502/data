#include<sys/types.h>
#include<sys/socket.h>
#include<stdio.h>
#include<netdb.h>
#include<netinet/in.h>
#include<stdlib.h>
#include<string.h>
int main(){
	char buff[256];
	int sockfd, newsock, len;
	struct sockaddr_in sin;
	memset(&sin, 0, sizeof(sin));
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1){
		printf("Socket not Created...\n");
		exit(1);
	}
	printf("Socket Created\n");
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port = 111;
	int k;
	k = bind(sockfd, (struct sockaddr*)&sin, sizeof(sin));
	if(k==-1){
		printf("Binding Failed....\n");
		exit(1);
	}
	printf("Binding Successful\nWaiting for Connection.........\n");
	k = listen(sockfd, 5);
	if(k==-1){
		printf("Listen Failed....\n");
		exit(1);
	}
	newsock = accept(sockfd, (struct sockaddr *)&sin, &len);
	if(newsock == -1){
		printf("New Socket Creation failed\n");
		exit(1);
	}
	printf("New Socket Created\n");
	printf("Type \"End\" to end Connection\n");
	while(1){
		k = recv(newsock, buff, sizeof(buff), 0);
		if(k == -1){
			printf("Error in Receiving\n");
			exit(1);
		}
		printf("%s", buff);
		if(strncmp(buff, "End", 3) == 0){
                        exit(1);
                }
		fgets(buff, sizeof(buff), stdin);
		k = send(newsock, buff, sizeof(buff), 0);
		if(k==-1){
			printf("Message Not Sent...\n");
			exit(1);
		}
	}
	close(newsock);
	close(sockfd);
	return 0;
}
