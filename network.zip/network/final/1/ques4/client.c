#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netdb.h>
#include<netinet/in.h>
#include<string.h>
#include<stdlib.h>
int main(){
	char buff[256];
	int conn, sockfd, k;
	struct sockaddr_in sin;
	memset(&sin, 0, sizeof(sin));
	
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1){
		printf("Socket not Created\n");
		exit(1);
	}
	
	printf("Socket Created\n");
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = inet_addr("127.0.0.1");
	sin.sin_port = 111;
	
	conn = connect(sockfd, (struct sockaddr*) &sin, sizeof(sin));
	if(conn == -1){
		printf("Connection to Server failed....\n");
		exit(1);
	}
	printf("Connection Successful......\n");
	
	printf("Type \"End\" to end communication\n");
	while(1){
		fgets(buff, sizeof(buff), stdin);
		k = send(sockfd, buff, sizeof(buff), 0);
		if(strncmp(buff, "End", 3)== 0){
			exit(1);
		}
		if(k==-1){
			printf("Message Not Sent\n");
			exit(1);
		}
		k = recv(sockfd, buff, sizeof(buff), 0);
		if(k==-1){
			printf("Error in Receiving\n");
			exit(1);
		}
		printf("%s", buff);
	}
	close(sockfd);
	return 0;
}
