1. go to current directory in which these programs are is contained while compiling.
2. compile and execute these programs in different terminals as shown in q3.png.

3. compile and execute server program as:
	g++ server.cpp -pthread
	./a.out [port no]

4. compile and execute client program as:
	g++ client.cpp -pthread
	./a.out 127.0.0.1 [same port no as in server terminal]

5. when multipe clients are connected to server then type'list' to display the list of clients available for chat.

6. Send message using client name to whom you want to send message as shown 
		eg: i want to sent to rahul
			rahul: message1
			client2: message2 
7. Note: ":" is there after client names
