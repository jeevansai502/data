#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <arpa/inet.h>
#define MYPORT 3490 // the port users will be connecting to
#define BACKLOG 10 // how many pending connections queue will hold
int main(void)
{
	int sockfd,new_fd,yes=1,numbytes,filesize;
	char remote_addr[10],buffer[1024],filename[15];   
	struct sockaddr_in my_addr,remot_addr;
	int sin_size;
	FILE *fp;
	bzero(buffer,1024); 
	bzero(filename,15);
	if ((sockfd = socket(AF_INET,SOCK_STREAM,0))==-1)
	{
		perror("socket");
		exit(1);
	}
	if (setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(int)) == -1) 
	{
		perror("setsocket");
		exit(1);
	}
	my_addr.sin_family = AF_INET; // host byte order
	my_addr.sin_port = htons(MYPORT); // short, network byte order
	my_addr.sin_addr.s_addr = INADDR_ANY; // automatically fill with my IP
	memset(&(my_addr.sin_zero),'\0', 8); // zero the rest of the struct
	if(bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr))==-1)
	{
		perror("bind");
		exit(1);
	}
	if(listen(sockfd, BACKLOG) == -1) 
	{
		perror("listen");
		exit(1);
	}
	sin_size = sizeof(struct sockaddr_in);
	if ((new_fd = accept(sockfd, (struct sockaddr *)&remot_addr,&sin_size)) == -1)
	{
		perror("accept");
	}
	// remote_addr=inet_ntoa(remot_addr.sin_addr);
	printf("server got connection from %s\n",inet_ntoa(remot_addr.sin_addr) );
	if ((numbytes=recv(new_fd,filename,14, 0)) == -1) 
	{
		perror("recv");
		printf("\n error  message: not recieved");
	} 

	filename[numbytes]='\0';
	printf("\n %s",filename);
	fp=fopen(filename,"r");
	fseek(fp,0,SEEK_END);
	filesize=ftell(fp);
	printf("%d",filesize);     
	fseek(fp,0,SEEK_SET);
	if(send(new_fd,&filesize,sizeof(filesize), 0)==-1)
	{
		perror("send");
		printf("\n error  message: not sent"); 
	}
	while ( fgets ( buffer, 1023,fp ) != NULL ) 
	{
		if((numbytes=send(new_fd,buffer,strlen(buffer), 0)) == -1) 
		{
			perror("send");
			printf("\n error  message: not sent");
		}
		printf("\n%d\n",numbytes);  
		bzero(buffer,1024); 
	}
	fclose(fp);
	close(new_fd);
	close(sockfd);
	return 0;
}

