#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
int main(void)
{
	int sockfd, numbytes,filesize,temp,r=0;
	char buf[1024],message[15],addr[10];
	struct sockaddr_in their_addr; // connectors address information
	bzero(buf,1024); 
	bzero(message,15);   
	FILE *fp;
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		printf("socket");
		exit(1);
	}
	their_addr.sin_family = AF_INET; // host byte order
	their_addr.sin_port = htons(3490); // short, network byte order
	printf("enter the address of the server");
	scanf("%s",addr);  
	inet_aton(addr, &(their_addr.sin_addr)); 
	memset(&(their_addr.sin_zero), '\0', 8); // zero the rest of the struct
	if (connect(sockfd, (struct sockaddr *)&their_addr,  sizeof(struct sockaddr)) == -1)
	{
		perror("connect");
		exit(1);
	}
	printf("client got connected \n" ); 
	printf("\n client:enter the file name"); 
	scanf("%s",message); 
	if (send(sockfd,message,15, 0) == -1)
	{
		perror("send");
		printf("\n error  message: not sent");  
	} 
	fp=fopen("test1","w");
	if ((numbytes=recv(sockfd,&filesize,sizeof(filesize),0)) == -1) 
	{
		perror("recv");
		printf("\n error  message: not recieved");
	}
	//printf("\n%d\n",filesize); 
	if ((temp=recv(sockfd,buf,1023, 0)) == -1) 
	{
		perror("recv");
		printf("\n error  message: not recieved");
	}
	//printf("\ntempout: %d\n",temp);
	//buf[temp]='\0';
	fseek(fp,0,SEEK_END);
	fputs(buf,fp);
	if(temp==filesize)
	{
		printf("completed transfer\n");
		printf("\ntempout: %d\n",temp);
	}
	else
	{
		r=r+temp;
		//printf("%d\n",r);
		while(temp)
		{
			if ((temp=recv(sockfd,buf,1023, 0)) == -1) 
			{
				perror("recv");
				printf("/n error  message: not recieved");
			}
			if(temp!=-1)
				r=r+temp;
			buf[temp]='\0';
			fseek(fp,0,SEEK_END);
			fputs(buf,fp);
			bzero(buf,1024);
			printf("%d\n",r);
			if(r==filesize)
			{
				printf("completed transfer");
				break;
			}
		}
	}
	bzero(buf,1024);
	fclose(fp);
	close(sockfd);
	return 0;
}

