#include<iostream>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<string.h>
#include<cstring>
#include<arpa/inet.h>
#include<stdlib.h>

using namespace std;
int main()
{
	int sockfd;
	struct sockaddr_in serv_addr;
	bzero(&serv_addr,sizeof(serv_addr));
	sockfd=socket(AF_INET,SOCK_STREAM,0);
	serv_addr.sin_family=AF_INET;
	serv_addr.sin_port=htons(6009);
	inet_aton("172.17.7.12",&(serv_addr.sin_addr));

	int e=connect(sockfd,(sockaddr*)&serv_addr,sizeof(serv_addr));
	if(e==-1)
	{
		printf("\nerror while connecting");
		 return 0;
	}
	string msg;
	char *buf=(char *)malloc(1024);
	while(1)
	{
		cout<<"enter the id no.:";
		cin>>msg;
		const char *ms=msg.c_str();
                int e1=send(sockfd,(const char *)ms,strlen(ms),0);
		bzero(buf,1024);
		int e2=recv(sockfd,buf,1024,0);
		puts(buf);
	}

	close(sockfd);
	return 0;
} 
