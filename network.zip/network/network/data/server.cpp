#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>
#include<iostream>
#include<stdio.h>
#include<stdlib.h>

using namespace std;

#define MYPORT 6009

int main()
{
	int sockfd,destfd,yes=1;
	struct sockaddr_in myaddr,destaddr;
	bzero(&myaddr,sizeof(myaddr));
	bzero(&destaddr,sizeof(destaddr));
	myaddr.sin_family=AF_INET;
	myaddr.sin_port=htons(MYPORT);
	inet_aton("172.17.7.12",&(myaddr.sin_addr));
	sockfd=socket(AF_INET,SOCK_STREAM,0);
	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes,sizeof(int)) == -1) 
{
    perror("setsockopt");
    exit(1);
}

	int e=bind(sockfd,(sockaddr*)&myaddr,sizeof(myaddr));
	if(e==-1)
	{
		printf("\nerror while binding");
		return 0;
	}

	listen(sockfd,5);

	socklen_t sin_size=sizeof(destaddr);

	int newfd=accept(sockfd,(sockaddr*)&destaddr,&sin_size);

	if(newfd==-1)
	{
		printf("\nerror while accepting");
		return 0;
	}
	char *buf=(char *)malloc(1024);
	string msg;
	FILE *fp;
	fp=fopen("database.txt","r");
	if(fp==NULL)
	{
		printf("Error: can't open file.\n");
		return 1;
	}
	else
	{
		printf("File opened successfully.\n\n");
	}
	while(1)
	{
		bzero(buf,1024);
		int e1=recv(newfd,buf,1024,0);
		fseek (fp,0,SEEK_SET);
		char d=*buf;
		int n=d-48;
		char c[50];
		int k=0;
		while((fscanf(fp,"%d %s",&k,c))!=-1)
		{
			if(k==n)
			break;
		}
		msg=c;
		const char *ms=msg.c_str();
		int e2=send(newfd,(const char *)ms,strlen(ms),0);
	}
fclose(fp);
close(newfd);
close(sockfd);
	return 0;
}
