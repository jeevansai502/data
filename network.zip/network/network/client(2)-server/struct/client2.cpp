#include<iostream>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<string.h>
#include<cstring>
#include<arpa/inet.h>
#include<stdlib.h>
#include<unistd.h>

using namespace std;

struct aa
{
  char c;
  int  n;
  float num;
};
int main()
{
	int sockfd;
	struct aa d,st;
	struct sockaddr_in serv_addr,destaddr2;
	bzero(&serv_addr,sizeof(serv_addr));
	sockfd=socket(AF_INET,SOCK_DGRAM,0);
	destaddr2.sin_family=AF_INET;
	destaddr2.sin_port=htons(5009);
	inet_aton("127.0.0.2",&(destaddr2.sin_addr));
	socklen_t addr_len = sizeof(struct sockaddr);
	int e=bind(sockfd,(sockaddr*)&destaddr2,sizeof(destaddr2));
	if(e==-1)
	{
		perror("\nerror while binding");
		return 0;
	}
	recvfrom(sockfd,&d,sizeof(d),0,(struct sockaddr *)&serv_addr, &addr_len);
		cout<<d.c<<endl;
		cout<<d.n<<endl;
		cout<<d.num<<endl;
	close(sockfd);
	return 0;
} 
