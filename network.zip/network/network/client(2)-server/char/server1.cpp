#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

using namespace std;

#define MYPORT 5008

int main()
{
	int sockfd,destfd;
	struct sockaddr_in myaddr,destaddr1,destaddr2;
	bzero(&myaddr,sizeof(myaddr));
	bzero(&destaddr1,sizeof(destaddr1));
        bzero(&destaddr2,sizeof(destaddr2));
	myaddr.sin_family=AF_INET;
	myaddr.sin_port=htons(MYPORT);
	myaddr.sin_addr.s_addr = INADDR_ANY;
	destaddr2.sin_family=AF_INET;
	destaddr2.sin_port=htons(5009);
	inet_aton("127.0.0.2",&(destaddr2.sin_addr));
	sockfd=socket(AF_INET,SOCK_DGRAM,0);

	int e=bind(sockfd,(sockaddr*)&myaddr,sizeof(myaddr));
	if(e==-1)
	{
		perror("\nerror while binding");
		return 0;
	}


	
	char *buf=(char *)malloc(1);
		string msg;
                socklen_t addr_len = sizeof(struct sockaddr);
		recvfrom(sockfd,buf,1,0,(struct sockaddr *)&destaddr1, &addr_len);
		int i=*buf;
		*buf=char(i-1);
		puts(buf);
		sendto(sockfd,buf,strlen(buf),0,(struct sockaddr *)&destaddr2, addr_len);
	close(sockfd);
	return 0;
}
