#include<iostream>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<string.h>
#include<cstring>
#include<arpa/inet.h>
#include<stdlib.h>
#include<unistd.h>

using namespace std;
int main()
{
	int sockfd;
	struct sockaddr_in serv_addr;
	bzero(&serv_addr,sizeof(serv_addr));
	sockfd=socket(AF_INET,SOCK_DGRAM,0);
	serv_addr.sin_family=AF_INET;
	serv_addr.sin_port=htons(5008);
	inet_aton("127.0.0.1",&(serv_addr.sin_addr));
	socklen_t addr_len = sizeof(struct sockaddr);
	string msg;
		cout<<"client1:";
		cin>>msg;
		const char *ms=msg.c_str();
                sendto(sockfd,(const char *)ms,strlen(ms),0,(struct sockaddr *)&serv_addr, addr_len);

	close(sockfd);
	return 0;
} 
