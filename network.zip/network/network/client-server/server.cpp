#include<sys/types.h>
#include<bits/stdc++.h>
#include<netinet/in.h>

using namespace std;

#define MYPORT 5008

int main()
{
	int sockfd,destfd;
	struct sockaddr_in myaddr,destaddr;
	bzero((char *) &myaddr, sizeof(myaddr));
	myaddr.sin_family=AF_INET;
	myaddr.sin_port=htons(MYPORT);
	myaddr.sin_addr.s_addr = INADDR_ANY;

	sockfd=socket(AF_INET,SOCK_STREAM,0);

	if (sockfd < 0) {
		perror("ERROR opening socket");
		exit(-1);
	}


	int e=bind(sockfd,(struct sockaddr*)&myaddr,sizeof(myaddr));
	if(e<0)
	{
		perror("\nerror while binding");
		exit(-1);
	}


	listen(sockfd,5);

	socklen_t sin_size=sizeof(destaddr);

	int newfd=accept(sockfd,(sockaddr*)&destaddr,&sin_size);

	if(newfd<0)
	{
		perror("\nerror while accepting");
		exit(-1);
	}
	char *buf=(char *)malloc(1024);
	string msg;

	while(1)
	{
		bzero(buf,1024);
		int e1=recv(newfd,buf,1024,0);
		puts(buf);
		cout<<"Server:";
		getline(cin,msg);
		msg="Server:"+msg;
		const char *ms=msg.c_str();
		int e2=send(newfd,(const char *)ms,strlen(ms),0);

	}

	return 0;
}
