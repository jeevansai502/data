/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_CHANGE3_TAB_H_INCLUDED
# define YY_YY_CHANGE3_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    ID = 258,
    NUMCONST = 259,
    CHARCONST = 260,
    BREAK = 261,
    ELSE = 262,
    IF = 263,
    INT = 264,
    FLOAT = 265,
    STRING = 266,
    RETURN = 267,
    WHILE = 268,
    RECORD = 269,
    STATIC = 270,
    NOT = 271,
    OR = 272,
    FALSE = 273,
    TRUE = 274,
    CHAR = 275,
    BOOL = 276,
    AND = 277,
    CAPITAL = 278,
    COMMENT = 279,
    VARIABLE = 280,
    CLASS = 281,
    INPUT = 282,
    OUTPUT = 283,
    IN_SYM = 284,
    OUT_SYM = 285,
    LT_EQ = 286,
    GT_EQ = 287,
    EQ_EQ = 288,
    NOT_EQ = 289,
    PL_PL = 290,
    MI_MI = 291,
    PL_EQ = 292,
    MI_EQ = 293,
    MU_EQ = 294,
    DI_EQ = 295,
    SEMI_COLON = 296,
    FL_BR_L = 297,
    FL_BR_R = 298,
    QUES = 299,
    PL = 300,
    MI = 301,
    MU = 302,
    MO = 303,
    DI = 304,
    EQ = 305,
    GT = 306,
    LT = 307,
    BR_L = 308,
    BR_R = 309,
    COMMA = 310,
    SQ_BR_L = 311,
    SQ_BR_R = 312,
    COLON = 313
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 39 "change3.y" /* yacc.c:1909  */

		std::string *s;
        

#line 118 "change3.tab.h" /* yacc.c:1909  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_CHANGE3_TAB_H_INCLUDED  */
