#include<bits/stdc++.h>

std::vector< std::map< std::string , std::pair<std::string , std::string> > > vec;
std::map< std::string , int> funMap;

void addScope(){

	std::map< std::string , std::pair<std::string , std::string> > m;	
	vec.push_back(m);
}

void addVariable(std::string name, std::string type, std::string value){

	std::pair <std::string , std::string> p;
	p.first = type;
	p.second = value;
	(vec.back())[name] = p;	
}

void exitScope(){

	if(!vec.empty()){
		vec.pop_back();
	}
}


std::pair<std::string , std::string> search(std::string str){

	std::vector< std::map< std::string , std::pair<std::string , std::string> > >::iterator it;

	for(it=vec.end()-1 ; it >= vec.begin(); it-- ) {

		if((*it).find(str) != (*it).end()){
		
			return (*it)[str];
		}
	}	
}	


int find(std::string str){

	std::vector< std::map< std::string , std::pair<std::string , std::string> > >::iterator it;

	for(it=vec.end()-1 ; it >= vec.begin(); it-- ) {

		if((*it).find(str) != (*it).end()){
			return 1;
		}
	}		
	return 0;
}	

